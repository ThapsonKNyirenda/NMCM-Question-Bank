# fictional-university-theme

This is my first WordPress custom theme. I will be tweaking it off and on to use it for my church's website eventually.
