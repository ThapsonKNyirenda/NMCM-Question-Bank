***********************
Distance-Regular Graphs
***********************

.. automodule:: networkx.algorithms.distance_regular
.. autosummary::
   :toctree: generated/

   is_distance_regular
   is_strongly_regular
   intersection_array
   global_parameters
