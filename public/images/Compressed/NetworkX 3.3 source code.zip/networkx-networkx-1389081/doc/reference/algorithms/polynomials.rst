*****************
Graph Polynomials
*****************

.. automodule:: networkx.algorithms.polynomials
.. autosummary::
   :toctree: generated/

   tutte_polynomial
   chromatic_polynomial
