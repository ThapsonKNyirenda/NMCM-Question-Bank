.. _ismags:

.. automodule:: networkx.algorithms.isomorphism.ismags

ISMAGS object
-------------
.. currentmodule:: networkx.algorithms.isomorphism

.. autosummary::
   :toctree: generated/

   ISMAGS
