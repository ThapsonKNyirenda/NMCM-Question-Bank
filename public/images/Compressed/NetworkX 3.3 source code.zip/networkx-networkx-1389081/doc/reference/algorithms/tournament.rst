**********
Tournament
**********

.. automodule:: networkx.algorithms.tournament
.. autosummary::
   :toctree: generated/

   hamiltonian_path
   is_reachable
   is_strongly_connected
   is_tournament
   random_tournament
   score_sequence
