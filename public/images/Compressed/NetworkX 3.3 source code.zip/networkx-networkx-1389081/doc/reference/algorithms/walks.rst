*****
Walks
*****

.. automodule:: networkx.algorithms.walks
.. autosummary::
   :toctree: generated/

   number_of_walks
