<?php

namespace BookStack\Exceptions;

use Exception;

class HttpFetchException extends Exception
{
}
