<?php

namespace BookStack\Exceptions;

class ConfirmationEmailException extends NotifyException
{
}
