<?php

namespace BookStack\Access\Oidc;

use Exception;

class OidcException extends Exception
{
}
