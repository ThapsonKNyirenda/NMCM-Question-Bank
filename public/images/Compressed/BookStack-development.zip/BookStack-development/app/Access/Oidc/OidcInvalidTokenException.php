<?php

namespace BookStack\Access\Oidc;

use Exception;

class OidcInvalidTokenException extends Exception
{
}
