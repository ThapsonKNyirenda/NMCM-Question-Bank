# Changelog

All notable changes to `Vue Argon Dashboard Laravel`  will be documented in this file.

## Version 2.0.0
- Vue Argon Dashboard 2
- Bootstrap5
- Update to Vue3
- Updates to the CRUD components

## Version 1.0.0

### Added
- Vue Argon Dashboard
- Login
- Register
- Profile edit
